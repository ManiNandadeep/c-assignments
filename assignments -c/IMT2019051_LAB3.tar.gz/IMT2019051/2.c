/*INPUT=string S containing lower-case English alphabets and integer L
*OUTPUT=the number of distinct substrings of length L of string S*/

#include<stdio.h>
#include<string.h>
int main(void)
{
	char S[20000],s1[20000],s2[20000];//S is the char array string,s1 is char array substring1,s2 is char string substring2
	int i,j,k,len,L,mark=0,unique=0;//necessary variables
	scanf("%s %d",S,&L);
	len=strlen(S);//finding the length
	if(L<=len)
	{
		for(i=0;i<=len-L;i++)
		{
			for(j=0;j<L;j++)
				s1[j]=S[i+j];//assaigning letters in substring1 
			for(j=0;j<len-L-i;j++)
			{
				for(k=0;k<L;k++)
					s2[k]=S[i+j+k+1];//assaigning letters in substring2
				if(strcmp(s1,s2)==0)//checking whether the substrings equal or not
					mark++;
			}
			if(mark==0)
				unique++;//counting the number of unique substrings
			mark=0;
		}
		printf("%d",unique);//printing result
	}
	else
	{
		printf("0");//corner case
	}
	return 0;
}
