/*INPUT=coordinates of centers of two circles,radius of two circles
 * OUTPUT=whether the two circles intersect or not*/
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main(void)
{
	int x1,y1,r1,x2,y2,r2;
      float distance;	//the variable 'distance' is the distance between the  centres of given two circles
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&r1,&r2);
	if(r1<0||r2<0)
	{
		printf("Invalid input");
		return 0;
	}
	else
	{
		distance=sqrt(pow(x1-x2,2)+pow(y1-y2,2));//calculating the distance 
		if((distance<=r1+r2)&&(distance>=abs(r1-r2)))//checking condition for intersection
		{
			printf("YES");
		}
		else
			printf("NO");
	}
	return 0;
}
