/*Usage of system*/
#include<stdio.h>
#include<stdlib.h>
int main(void)
{
	FILE*fp1,*fp2;
	char ch;
	system("date>file1.txt");	//using the >(redirect operator) operator to send the information into the txt file	
	system("sleep 5");		//pausing for 5 seconds...
	system("date>file2.txt");
	fp1=fopen("file1.txt","r");
	fp2=fopen("file2.txt","r");
	while(1)
	{
		ch=fgetc(fp1);		//writing each and every character using the fgetc function
		if(ch==EOF)		//breaking the loop if ch is end of file
			break;
		printf("%c",ch);
	}
	while(1)
	{
		ch=fgetc(fp2);
		if(ch==EOF)
			break;
		printf("%c",ch);
	}
	fclose(fp1);		//closing the file1
	fclose(fp2);		//closing the file2
	return 0;
}
