#include<stdio.h>
int max(int m,int n)
{
	if(m>n)
		return m;	//max function returns the maximum degree among the two polynomial
	else
		return n;
}
void add(int d1,int d2,double arr1[],double arr2[])	//the function add prints the addition of the two polynomials
{
	int count=0;
	int size=max(d1,d2);
	int temp=size;
	double sum[size+1];
	for(int i=0;i<=size;i++)
	{
		sum[i]=0;
	}
	for(int i=d1;i>=0;i--)
	{
		sum[temp]+=arr1[i];
		temp--;
	}
	temp=size;
	for(int i=d2;i>=0;i--)
	{
		sum[temp]+=arr2[i];
		temp--;
	}
	for (int i=0;i<=size;i++)
	{
		if (sum[i]==0)
		{
			count++;
			continue;
		}
		else
			break;
	}
	if (size-count>=0)
		printf("%d ",size-count);
	for (int i=count;i<=size;i++)
	{
		printf("%lf ",sum[i]);
	}
}
void multiply(int d1,int d2,double arr1[],double arr2[])	//the function multiply prints the multiplication of the two polynomials
{
	int i,j;
	double arr[d1+d2+1];
	for(i=0;i<=d1+d2;i++)
	{
		arr[i]=0;
	}
	for(i=0;i<=d1;i++)
	{
		for(j=0;j<=d2;j++)
			arr[i+j]+=arr1[i]*arr2[j];
	}
	printf("%d ",d1+d2);
	for(i=0;i<=d1+d2;i++)
	{
		printf("%lf ",arr[i]);
	}
}
int main(void)
{
	int d1;
	scanf("%d",&d1);
	double arr1[d1+1];
	for(int i=0;i<d1+1;i++)
	{
		scanf(" %lf",&arr1[i]);
	}
	int d2;
	scanf("%d",&d2);
	double arr2[d2+1];
	for(int i=0;i<d2+1;i++)
	{
		scanf(" %lf",&arr2[i]);
	}
	add(d1,d2,arr1,arr2);		//calling the add function
	printf("\n");
	multiply(d1,d2,arr1,arr2);	//calling the multiply function
	return 0;
		
}
