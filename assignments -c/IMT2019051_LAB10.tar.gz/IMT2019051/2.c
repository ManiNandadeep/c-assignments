/* Usage of variable arguments for writing minprint function*/
#include<stdio.h>
#include<stdarg.h>	//included the stdarg header file
void minprint(char*format,...);
int main()
{
	int i;
	scanf("%d",&i);
	char*c;
	scanf("%s",c);
	minprint("%d",i);
	minprint("%s",c);
	return 0;
}
void minprint(char*format,...)
{
	va_list var;	//initializing va_list variable
	char*p,*sval;
	int ival;	//ival is the integer value to be printed
	va_start(var,format);	//initialized the va_start macro
	for(p=format;*p!='\0';p++)
	{
		if(*p!='%')
		{
			putchar(*p);
			continue;
		}
		switch(*++p)
		{							//using the switch case
			case 'd':
				ival=va_arg(var,int);
				if(ival<0)
				{
					putchar('-');		
					ival=-ival;		
				}
				if(ival==0)
				{
					putchar('0');
				}
				if(ival/10)
				{
					minprint("%d",ival/10);			//recursively calling minprint function to print integer
				}
				putchar(ival%10+'0');
				break;
			case 's':
				for(sval=va_arg(var,char*);*sval;sval++)
					putchar(*sval);
				break;
			default:
				putchar(*p);
				break;
		}
	}
	va_end(var);						
}

