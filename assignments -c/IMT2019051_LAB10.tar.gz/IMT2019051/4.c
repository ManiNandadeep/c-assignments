#include<stdio.h>
int main(void)
{
	FILE*fp3,*fp1,*fp2;
	char ch;
	fp1=fopen("file1.txt","r");
	fp2=fopen("file2.txt","r");
	fp3=fopen("file3.txt","w+");
	while(1)
	{
		ch=fgetc(fp1);
		if(ch==EOF)
			break;
		fputc(ch,fp3);
	}
	while(1)
	{
		ch=fgetc(fp2);
		if(ch==EOF)
			break;
		fputc(ch,fp3);
	}
	fclose(fp1);
	fclose(fp2);
	fclose(fp3);
	return 0;
}
