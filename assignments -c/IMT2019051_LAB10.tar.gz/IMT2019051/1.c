/*usage of command line arguments to print the number of arguments given and their sum*/
#include<stdio.h>
int main(int argc,char *argv[])
{
	int sum=0;
	printf("%d ",argc-1);
	for(int i=0;i<argc-1;i++)
	{
		int j;
		sscanf(argv[i+1],"%d",&j);	//using the sscanf function
		sum+=j;
	}
	printf("%d",sum);
	return 0;
}

