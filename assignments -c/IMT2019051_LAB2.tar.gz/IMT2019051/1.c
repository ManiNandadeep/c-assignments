#include<stdio.h>
int main(void)
{
	int dividend,divisor,remainder,x,y;
	scanf("%d %d",&x,&y);
	if(x<0)
	 x=-x;
	if(y<0)
	 y=-y;
	if(x==0&&y==0)
	{printf("Invalid input");
	return 0;}
	if(x>=y)
	 {
		 dividend=x;
		 divisor=y;
	 }
	else
	{
		dividend=y;
		divisor=x;
	}
	if(divisor==0)
	{
		printf("%d",dividend);
		return 0;
	}
	remainder=dividend % divisor;
	if(remainder==0)
	     {	printf("%d",divisor);
		     return 0;}
	while(remainder>0)
       {
		remainder=dividend % divisor;
		dividend=divisor;
		divisor=remainder;
			
       }
       
	printf("%d",dividend);
       
       return 0;
}
