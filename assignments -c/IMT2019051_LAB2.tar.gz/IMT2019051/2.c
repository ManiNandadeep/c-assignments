/*to write a programme on Sieve of Eratosthenes*/
#include<stdio.h>
#include<stdbool.h>
#include<math.h>
int main(void)
{
   long long int i,j,n,m=0;
   bool a[20000];
   scanf("%lld",&n);
   for(i=2;i<=n;i++)
	   a[i]=1;
   for(i=2;i<=sqrt(n);i++)
	   for(j=2;i*j<=n;j++)
		   a[i*j]=0;
   for(i=2;i<=n;i++)
	   if(a[i]==1)
		   m++;
   		  
    printf("%lld",m);
    return 0;

}
