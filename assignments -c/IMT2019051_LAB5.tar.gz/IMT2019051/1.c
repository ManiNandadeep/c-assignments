/*BUBBLE SORT */
#include<stdio.h>
#define swap(x,y) long long int t;t=x;x=y;y=t;		//creating a macro for swapping
int bubblesort(long long int array[]);			//declaring bubblesort function
int main(void)
{
	long long int array[20];			
        int i;
	for(i=0;i<20;i++)
		scanf("%lld,",&array[i]);		//taking the input 
	bubblesort(array);				//calling the bubblesort function
	return 0;
}
int bubblesort(long long int array [])
{
	int i,j;
	int swappings=0,comparisions=0;			//swapping is the number of times swap(x,y) is called.
	for(i=0;i<19;i++)				//comparisions is the number of times two elements of the array are compared
	{
		for(j=0;j<19-i;j++)
		{
			comparisions++;
			if(array[j]>array[j+1])		//comparing the adjacent elements of the array 
			{
				swappings++;
				swap(array[j],array[j+1]);
			}

		}
	}
	for(i=0;i<20;i++){
		printf("%lld ",array[i]);		//printing the sorted array
	}
	printf("\n%d %d",swappings,comparisions);
	return 0;

}
