/*QUICK SORT*/
#include<stdio.h>
#define swap(x,y) long long int t;t=x;x=y;y=t;	//creating a macro for swapping
int global=0,pi;		//introducing a global argument to store the value of n
int printsorted(long long int array[],int n)	//this is  a function for printing the sorted array and the pivot index
{
	int i=0;
	while(i<n)
	{
		printf("%lld ",array[i]);
		i++;
	}
	printf("\n%d",pi);
	return 0;
}
int partition(long long int array[],int l,int h)			//this is a function to partition (split) the array
{
	int i=l-1;
	if(l<h)
	{
		long long int pivot=array[h];			//taking the last element i.e array[h] as the pivot
		for(int j=l;j<=h-1;j++)
		{
			if(array[j]<pivot)
			{
				i++;
				swap(array[i],array[j]);
			}
		}
		swap(array[i+1],array[h]);
	}
		return (i+1);
}
int quicksort(long long int array[],int l,int h)
{
	if(l<h)
	{
		int pivot_index=partition(array,l,h);
		if(l==0&&h==global-1)
			pi=pivot_index;																		//the variable pi stores the pivot_index of the element array[h]
		quicksort(array,l,pivot_index-1);
		quicksort(array,pivot_index+1,h);
	}
	return 0;
}
int main(void)
{
	int i,n;
	scanf("%d",&n);
	long long int array[n];			//long long int is used to satisfy the range given in the question
	global=n;
	scanf("%lld",&array[0]);
	for(i=1;i<n;i++)
		scanf(",%lld",&array[i]);
	quicksort(array,0,n-1);
	printsorted(array,n);
	return 0;
}
