/*SELECTION SORT*/
#include<stdio.h>
#define swap(x,y) long long int temp;temp=x;x=y;y=temp;		//creating a macro for swapping
int selectionsort (long long int array[]);	//function to impliment selectionsort
int main(void)
{
	long long int array[20],i;
	scanf("%lld",&array[0]);
	for(i=1;i<20;i++)
		scanf(",%lld",&array[i]);
	selectionsort(array);
	return 0;
}
int selectionsort(long long int array[])
{
	long long int i,j,min,swaps=0,comparisions=0;
	for(i=0;i<19;i++)
	{
		min=i;		//finding out the index of the minimum element
		for(j=i+1;j<20;j++)
		{
			comparisions++;
			if(array[j]<array[min])
				min=j;
		}

			swap(array[i],array[min]);
			++swaps;

	}
	for(i=0;i<20;i++)
		printf("%lld ",array[i]);		//printing the sorted array
	printf("\n%lld %lld",swaps,comparisions);		//printing the number of swaps and comparisions done
	return 0;
}
