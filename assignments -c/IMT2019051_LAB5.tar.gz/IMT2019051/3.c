/*program for merge sort*/
#include<stdio.h>
int count=0;      //count is the variable which contains the number of times merge function is called
int merge(long long int array[],int l,int m,int r);   //declaring a function called merge
int mergesort(long long int array[],int l,int r)
{
        int m;
        if(l<r){
                m=l+(r-l)/2;
                mergesort(array,l,m);
                mergesort(array,m+1,r);         //uses divide and conquire principle
                merge(array,l,m,r);
		count++;
        }
	return 0;
}
int sortedarray(long long int array[],int n)    //this function prints the sorted array
{
        int i;
        for (i=0;i<n;i++)
                printf("%lld ",array[i]);
	printf("\n%d",count);
        return 0;
}
int main(void)
{
	long long int array[100],i,n;
	scanf("%lld\n",&n);
	scanf("%lld",&array[0]);     //taking elements which are seperated by commas
	for(i=1;i<n;i++)
		scanf(",%lld",&array[i]);
	mergesort(array,0,n-1);
	sortedarray(array,n);
	return 0;
}
int merge(long long int array[],int l,int m,int r)
{
	int i,j,k;
	int temp1=m-l+1;
	int temp2=r-m;
	long long int left[temp1],right[temp2];    //left and right are two duplicate arrays created
	for(i=0;i<temp1;i++)
		left[i]=array[l+i];
	for(j=0;j<temp2;j++)
		right[j]=array[m+j+1];
	i=0;
	j=0;
	k=l;
	while(i<temp1 && j<temp2){
		if(left[i]<=right[j]){
                        array[k]=left[i];
                        i++;
                }
		else{
                        array[k]=right[j];
                        j++;
                }

		k++;
	}
	while(i<temp1){
		array[k]=left[i];
		i++;
		k++;
	}
	while(j<temp2){
		array[k]=right[j];
		j++;
		k++;
	}
	return 0;
}
