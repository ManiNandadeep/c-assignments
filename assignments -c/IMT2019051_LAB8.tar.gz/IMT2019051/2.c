#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int strend(char *s,char *t)
{
	int i,j;
	for(i=strlen(s)-strlen(t),j=0;i<strlen(s);i++,j++)	
	{
		if(*(s+i)!=*(t+j))	//condition to check
		{
			return 0;
		}
	}
	return 1;
}
int main(void)
{
	char*s,*t;
	s=(char*)malloc(255*sizeof(char));
	t=(char*)malloc(255*sizeof(char));	//allocating memory dynamically
	scanf("%s %s",s,t);
	int result=strend(s,t);		//calling the strend function
	if(result==1)
		printf("%s",t);
	else
		printf("0");
	free(s);
	free(t);	//freeing up the space alloted
	return 0;
}
