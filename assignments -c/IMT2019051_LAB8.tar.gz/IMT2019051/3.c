#include<stdio.h>
#include<stdlib.h>
void add(double num1,double num2)
{
	printf("%.4lf",num1+num2);	//add function
}
void subtract(double num1,double num2)
{
	printf("%.4lf",num1-num2);	//subtract function
}
void multiply(double num1,double num2)
{
	printf("%.4lf",num1*num2);	//multiply function 
}
void division(double num1,double num2)
{
	printf("%.4lf",num1/num2);	//division function
}
int main(void)
{
	double num1,num2;
	char*c;
	c=(char*)malloc(sizeof(char));
	scanf("%lf %lf %c",&num1,&num2,c);
	if(*c=='+')
	{
		void(*func_ptr)(double,double)=&add;	//functional pointer to add
		func_ptr(num1,num2);
	}
	if(*c=='-')
	{
		void(*func_ptr)(double,double)=&subtract;	//functional pointer to subtract
		func_ptr(num1,num2);
	}
	if(*c=='*')
	{
		void(*func_ptr)(double,double)=&multiply;	//functional pointer to multiply
		func_ptr(num1,num2);
	}
	if(*c=='/')
	{
		void(*func_ptr)(double,double)=&division;	//functional pointer to division
		func_ptr(num1,num2);
	}
	free(c);	//freeing up the allocated memory
	return 0;
}
