#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define swap(a,b) int t;t=a;a=b;b=t; 	//defining a macro for swapping 
void mystrrev(char* s)
{
	for(int i=0;i<strlen(s)/2;i++)
	{
		swap(*(s+i),*(s+strlen(s)-i-1));	
	}
}
int base_b(int num)
{
	if(num>=0&&num<=9)
		return (char)(num+'0');		//type-casting int to char
	else
		return (char)(num-10+'a');	
}
void itob(int n,char*s,int b)
{
	int i;
	s=(char*)malloc(64*sizeof(char));	//allocating memory dynamically
	for(i=0;n>0;i++)
	{
		*(s+i)=base_b(n%b);	//calling the base_b function
		n=n/b;
	}
	*(s+i)='\0';
	mystrrev(s);			//calling the strrev function
	printf("%s",s);
	free(s);			//freeing up the allcated memory
}
int main(void)
{
	int n,b;
	char*s;				
	scanf("%d %d",&n,&b);
	if(b<=32&&b>1)
		itob(n,s,b);	//condition for calling itob function
	return 0;
}
