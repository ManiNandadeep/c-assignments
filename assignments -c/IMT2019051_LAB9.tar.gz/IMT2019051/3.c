#include<stdio.h>
struct details{		//structure containing the details
	char name[20];
	char roll[20];
	int age;
	int marks;
};
int main(void)
{
	int n;
	scanf("%d",&n);
	struct details s[n];	
	for (int i=0;i<n;i++)
	{
		scanf("%s %s %d %d",s[i].name,s[i].roll,&s[i].age,&s[i].marks);		
	}
	for (int i=0;i<n;i++)
	{
		printf("%s\n",s[i].name);	//printing the name
		printf("%s\n",s[i].roll);	//printing the rollnumber
		printf("%d\n",s[i].age);	//printing the age of the person
		printf("%d\n",s[i].marks);	//printing the marks
	}
	return 0;
}
