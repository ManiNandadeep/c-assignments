/* INPUT= take input of how many numbers required
 * OUTPUT= print the numbers and print the numbers which are even 
 * with the help of LINKED LIST*/
#include<stdio.h>
#include<stdlib.h>
struct Node
{
	int value;		//structure named Node which initializes a linked list
	struct Node*next;	
};
struct Node*head;
void Delete(int n)
{
	struct Node*temp1=(struct Node*)malloc(sizeof(struct Node));
	struct Node*temp2=(struct Node*)malloc(sizeof(struct Node));
	temp1=head;
	if(n==1)	//delete the first node
	{
		head=head->next;	
		free(temp1);
	}
	else		//delete the second node
	{
		for(int i=0;i<n-2;i++)
		{
			temp1=temp1->next;
		}
		temp2=temp1->next;
		temp1->next=temp2->next;
		free(temp2);			//here temp2 contains the address of the node to be deleted	
	}
}
void Insert(int x,int n)		//insert function to insert x in nth position
{
	struct Node* temp1=(struct Node*)malloc(sizeof(struct Node));
	temp1->value=x; 
	temp1->next=NULL;
	struct Node* temp2=(struct Node*)malloc(sizeof(struct Node));
	if (n==1)	//condition to insert x at first position
	{
		temp1->next=head;
		head=temp1;
	}
	else		//condition to insert x at nth position other than 1
	{
		temp2=head;
		for (int i=1;i<=n-2;i++)
		{
			temp2=temp2->next;
		}
		temp1->next=temp2->next;
		temp2->next=temp1;
	}
}
void print(void)
{
	struct Node*temp=head;
	while(temp!=NULL)	//traverse through the node until you get NULL
	{
		printf("%d",temp->value);
		printf("-->");
		temp=temp->next;
	}
	printf("NULL");
}
int main(void)
{
	struct Node*check=(struct Node*)malloc(sizeof(struct Node));
	head=NULL;
	int n,i,x;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&x);
		Insert(x,i);	//inserting x at ith position
	}
	print();
	check=head;
     	for(i=1;check!=NULL;i++)
	{
		if((check->value)%2!=0)	//delete the node which contains odd number
		{
			Delete(i);
			i--;
			check=check->next;
		}
		else
		{
			check=check->next;	//else increment check
		}
	}
	printf("\n");
	print();	
	return 0;
}
