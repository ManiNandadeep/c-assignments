#include<stdio.h>
struct point{		//structure point to store the x and y coordinates of a point 

	float x;
	float y;	
};
int main(void)
{
	struct point p1,p2;
	scanf("%f %f",&p1.x,&p1.y);
	scanf("%f %f",&p2.x,&p2.y);
	printf("%.2f + %.2fi\n",p1.x+p2.x,p1.y+p2.y);	//printing the addition of two complex numbers
	printf("%.2f + %.2fi\n",p1.x-p2.x,p1.y-p2.y);	//printing the substraction of two complex numbers
	printf("%.2f + %.2fi",p1.x*p2.x-p1.y*p2.y,p1.x*p2.y+p1.y*p2.x);		//printing the multiplication of two complex number
	return 0;
}
