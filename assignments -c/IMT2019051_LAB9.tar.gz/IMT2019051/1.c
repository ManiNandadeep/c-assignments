/* using the argc and argv concept of main 
 * INPUT=4 arguments with two numbers and one operator 
 * OUTPUT=the result of operation between the two numbers*/
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char* argv[])
{
	if(argc==5)
	{
		int a,b;
 	      	a=atoi(argv[2]);
       		b=atoi(argv[3]);
        	char ch = (argv[4])[0];
        	float result;
		switch(ch)
		{
			case '+':			//+ symbol for addition
				result=a+b;
				printf("%f\n",result);
				break;
				
			case '-':			//- symbol for subtraction
				result=a-b;
				printf("%f\n",result);
				break;
				
			case '*':			//x symbol for multiplication
				result=a*b;
				printf("%f\n",result);
				break;
				
			case '/':
				if (b!=0)	// /symbol for division (given denomenator is not 0)
					printf("%f\n",(float)a/b);	
				break;
			default:
				printf("No case matched");
				
		}
	}
	else
	{
	  printf("Only 5 arguments are allowed");	//message when the given number of arguments donot match with 5
	}
	return 0;
}
