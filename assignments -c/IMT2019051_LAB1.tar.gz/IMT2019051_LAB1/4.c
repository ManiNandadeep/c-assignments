#include<stdio.h>
#include<math.h>
int main(void)
{
	double a,b,c,r1,r2,x,y;
	scanf("%lf %lf %lf",&a,&b,&c);
	if(a!=0)		
         {
          if (b*b-4*a*c>=0)
	    { r1=(-b+sqrt(b*b-4*a*c))/(2*a);
	      r2=(-b-sqrt(b*b-4*a*c))/(2*a);
	      printf("%.2lf %.2lf",r1,r2);
            } 
	  else
	    {
              x=-b/(2*a);
	      y=sqrt(4*a*c-b*b)/(2*a);
	      printf("%.2lf+i%.2lf %.2lf-i%.2lf",x,y,x,y);
	    }
          }
	return 0;
}
