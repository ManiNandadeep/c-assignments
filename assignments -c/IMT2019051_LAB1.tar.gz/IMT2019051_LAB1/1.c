#include<stdio.h>
int main(void)
{
	float a,r,p=3.14;
	scanf("%f",&r);
	if(r<0)
	  printf("Invalid input");
	else
	  {
		  a=p*r*r;
		  printf("%.2f",a);
	  }
	   return 0;
}
