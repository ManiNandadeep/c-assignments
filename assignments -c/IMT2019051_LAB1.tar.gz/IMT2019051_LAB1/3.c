#include<stdio.h>
int main(void)
{
    double cel,fah;
    scanf("%lf",&cel);
    fah=(9*cel)/5+32;
    printf("%.2lf",fah);
    return 0;
}
