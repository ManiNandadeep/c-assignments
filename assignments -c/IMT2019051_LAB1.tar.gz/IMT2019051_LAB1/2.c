#include<stdio.h>
int main (void)
{
	int a,b,r;
	scanf("%d%d",&a,&b);
	if (a<=0||b<=0)
	  printf("Invalid input");
	else
	{
	        if (a>=b)
		  {
			  r=a%b;
                          printf("%d",r);
		  }
		else
		{
			r=b%a;
			printf("%d",r);
		}
	}
	return 0;
}
