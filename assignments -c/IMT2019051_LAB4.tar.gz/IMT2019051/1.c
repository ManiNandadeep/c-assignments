/*to take 10 numbers seperated by comma's as input and print them in reverse order*/
#include<stdio.h>
int main(void)
{
	int array[10];
	scanf("%d",&array[0]);            
	for (int i=1;i<10;i++)
	{
		scanf(",%d",&array[i]);    //taking 10 elements which are seperated by commas as input
	}
	for (int i=9;i>=0;i--)             //loop for printing the given numbers in reverse order
	{
		printf("%d ",array[i]);
	}
	return 0;
}
