/*to write a program for linear search*/
#include<stdio.h>
int main(void)
{
	int array[11],j;         //declaring an int array of size 11 in which the 11th element is the number to search in.
	scanf("%d",&array[0]);                  
	for (int i=1;i<10;i++)
	{
		scanf(",%d",&array[i]); //taking input of numbers seperated by commas.
	}
	scanf(" %d",&array[10]);
	for(j=0;j<10;j++)
	{
		if(array[j]==array[10])   //comparing every element with the number to search in. 
		{
			printf("1 %d",j+1);  //if the number is found print 1 and number of comparisions done
			break;
		}

	}

       	if(array[9]!=array[10] && j==10)  
		printf("0 %d\n",j);       //if the number is not found print 0 and number of comparisions done
	return 0;
}
