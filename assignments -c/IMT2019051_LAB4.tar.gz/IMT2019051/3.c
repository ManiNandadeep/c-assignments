/*writing a program for binary search*/
#include<stdio.h>
int main(void)
{
	int arr[11],i,count=0;                  //declaring the variable count which gives us the number of comparision done
	scanf("%d",&arr[0]);
	for (i=1;i<10;i++)
		scanf(",%d",&arr[i]);             //taking 10 numbers as input which are sorted and seperated by commas.
	scanf(" %d",&arr[10]);                    //11th element is the element to search in.             
	int first=0,last=9,middle;                //introducing the variables first,last ,middle. 
	while(first<=last)
	{
		middle=(first+last)/2;           //caluculating the new middle term after every iteration
		if(arr[10]==arr[middle])
		{
			count++;                   //checking whether the middle term is equal to the number to search in 
			printf("1 %d",count);
			break;
		}
		else if(arr[middle]>arr[10])
		{
			count++;                      
			last=middle-1;             /*if the middle term is greater than the number to search in then reduce the 
							search space to the first half	*/
		}
		else
		{
			count++;
			first=middle+1;		/*if the middle term is smaller than the number to search in then reduce the 
						       search space to the second half*/
		}	
	}
	if(first>last)
		printf("0 %d",count);
	return 0;

}
