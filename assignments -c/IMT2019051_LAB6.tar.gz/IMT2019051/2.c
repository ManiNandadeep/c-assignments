/*to impliment our own string compare function using pointers */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int string_cmp(char*string1,char*string2)
{
	int i=0;
	while(*(string1+i)!='\0'||*(string2+i)!='\0')	
	{
		if(*(string1+i)!=*(string2+i))
		{
			return 1;				
			break;
		}
		else
			i++;
	}
	return 0;
}
int main(void)
{
  int s;
  char*string1;
  char*string2;
  string1=(char*)malloc(255*sizeof(char));	//alloting memory dynamically for string1 and string2
  string2=(char*)malloc(255*sizeof(char));
  scanf("%s %s",string1,string2);
  s=string_cmp(string1,string2);	//calling string_cmp function
  printf("%d",s);
  free(string1);
  free(string2);		//freeing up the memory allocated to  string1 and string2
  return 0;
}
