/* to take n numbers as input dynamically and printing them without using arrays*/
#include<stdio.h>
#include<stdlib.h>
int main(void)
{
  int i,j,n;
  int *ptr;
  scanf("%d",&n);
  ptr=(int*)malloc(n*sizeof(int));	//alloting memory dynamically
  for(i=0;i<n;i++)
    scanf(" %d",(ptr+i));  //taking numbers as inputs without using arrays
  for(j=0;j<n;j++)
    printf("%d ",*(ptr+j));	//printing numbers without using arrays
  free(ptr);
  return 0;
}
