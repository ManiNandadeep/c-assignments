/*to write a program for strcat using dynamic memory allocation*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void my_strcat(char*s1,char*s2)
{
	char*s;	
	s=(char*)malloc(600*sizeof(char));	//s is a string which is the result of concatenation of s1 and s2
	int i=0,j=0;
	while(*(s1+i)!='\0')
	{
		*(s+j)=*(s1+i);
		j++;
		i++;
	}
	i=0;
	while(*(s2+i)!='\0')		//here \0 is the de-limitor
	{
		*(s+j)=*(s2+i);
		j++;
		i++;
	}
	printf("%s",s);
}
int main(void)
{
	char*s1;
	char*s2;
	s1=(char*)malloc(300*sizeof(char));
	s2=(char*)malloc(300*sizeof(char));	//alloting memory for s1 and s2 dynamically
	scanf("%s %s",s1,s2);
	my_strcat(s1,s2);	//calling my_strcat function
	return 0;
}
